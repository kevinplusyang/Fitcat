//
//  log.h
//  FitCat
//
//  Created by Kevin Yang on 10/25/16.
//  Copyright © 2016 Cornell University Information Science. All rights reserved.
//

#ifndef log_h
#define log_h
int count = 0;

#endif /* log_h */
